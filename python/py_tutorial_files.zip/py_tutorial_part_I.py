
if __name__ == '__main__':

    ethene_atom_masses = [12.01, 12.01, 1, 1, 1, 1]

    total_mass = sum(ethene_atom_masses)
    n_atoms = len(ethene_atom_masses)

    # f-strings are the best practice string formatting
    print(f'There are {n_atoms} in ethene. '
          f'Its total mass is {total_mass:.1f} g / mol.')

    # You can combine strings with other objects using braces
    print(f'The total mass of carbon in ethene is '
          f'{ethene_atom_masses[0] + ethene_atom_masses[1]:.1f} g / mol.')

    # You can also print directly to a file and format variables in line
    with open('f-string_example.txt', 'w') as outfile:
        print(f'0123456789',
              f'{total_mass:.7f}',
              f'{total_mass:010}',
              f'{total_mass:10}',
              f'{total_mass:>9}',
              file=outfile, sep='\n')

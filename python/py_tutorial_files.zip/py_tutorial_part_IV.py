import numpy as np
from molecule import Molecule


def test_molecule():

    methane = ['C', 'H', 'H', 'H', 'H']
    molecule = Molecule(methane)

    assert hasattr(molecule, 'atoms')
    assert molecule.atoms is not None

    assert molecule.n_atoms == len(methane)

    mol_mass = molecule.calculate_molecular_mass()
    assert np.isclose(mol_mass, 16.05)

    molecule.add_atom_to_molecule('O')
    assert 'O' in molecule.atoms
    assert molecule.n_atoms == len(molecule) + 1

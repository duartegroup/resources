import numpy as np

atomic_mass_dictonary = {'C': 12.01, 'H': 1.01, 'O': 16.00}


def _get_atomic_mass(atom) -> float:
    """Get the atomic mass from a library"""

    if atom in atomic_mass_dictonary:
        return atomic_mass_dictonary[atom]

    else:
        raise ValueError(f'Atom {atom} is not in atom dictonary')


class Molecule:

    def __init__(self, atoms: list = None):
        """
        Molecule class containing a set of atoms

        -----------------------------------------------------------------------
        Arguments:

            atoms: List of atoms
        """
        self.atoms = atoms

    @property
    def n_atoms(self) -> int:
        """Returns the number of atoms in the molecule"""
        return len(self.atoms)

    def calculate_molecular_mass(self) -> float:
        """Calculates the molecular mass of a molecule"""
        atomic_masses = [_get_atomic_mass(atom) for atom in self.atoms]

        return sum(atomic_masses)

    def add_atom_to_molecule(self, atom: str) -> None:
        """Adds an atom to the molecule"""
        self.atoms.append(atom)

        return None


if __name__ == '__main__':

    methane = ['C', 'H', 'H', 'H', 'H']
    molecule = Molecule(methane)

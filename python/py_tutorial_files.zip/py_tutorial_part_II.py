import numpy as np


def _get_squared_sum_atomic_dist(atom_1: list, atom_2: list) -> float:
    """Calculates the sum of squares of diferences of atomic positions between 
    two atoms"""
    
    distances_squared = [(atom_1[i] - atom_2[i])**2 for i in range(3)]

    return sum(distances_squared)


def _get_distances_squared(mol_1: list, mol_2: list) -> list:
    """Calculates the sum of squares of difference of atomic positions between 
    all atoms in a molecule"""

    distances_squared = [_get_squared_sum_atomic_dist(
        atom_i, atom_j) for atom_i, atom_j in zip(mol_1, mol_2)]

    return distances_squared


def calculate_rmsd(mol_1: list, mol_2: list) -> float:
    """Calculates the RMSD of atomic positions between two molecules:

    RMSD  = √((1/n) * Σ_i ||v_i - w_i||^2)

    Where n is the number of atoms, v is molecule 1 and w is molecule 2
    """
    # Molecules must contain same number of atoms
    assert len(mol_1) == len(mol_2)

    distances_squarded = _get_distances_squared(mol_1, mol_2)
    normalised_sum = (1 / len(mol_1)) * sum(distances_squarded)

    return np.sqrt(normalised_sum)


def rmsd(a,b):
    d=[]
    for idxi, i in enumerate(a):
        for idxj, j in enumerate(b):
            if idxi == idxj:
                x=abs(i[0]-j[0])
                y=abs(i[1]-j[1])
                z=abs(i[2]-j[2])
                x=x**2
                y=y**2
                z=z**2
                d.append(x)
                d.append(y)
                d.append(z)
    sum_d=sum(d)
    n=1/len(a)
    n_sum_d=n*sum_d
    r=n_sum_d**0.5
    return r


if __name__ == '__main__':

    molecule_1 = [[0., 1., 1.],
                  [0., 1., 1.]]

    molecule_2 = [[0., 1., 1.],
                  [0., 0., 1.]]

    rmsd = rmsd(molecule_1, molecule_2)
    print(f'RMSD of molecule 1 and molecule 2: {rmsd:.2f}')

    rmsd = calculate_rmsd(molecule_1, molecule_2)
    print(f'RMSD of molecule 1 and molecule 2: {rmsd:.2f}')
